import pygame
from ball import Ball
from spiller import Spiller
from hinder import Hinder
import random


pygame.init()

BREDDE = 1280
HOYDE = 750
FPS = 60

baller = []
ball = Ball(BREDDE/2 - 15, HOYDE/2 - 15, 30, 30)
baller.append(ball)
spiller = Spiller(BREDDE - 10, HOYDE/2 - 70, 10, 140)
spiller2 = Spiller(10, HOYDE/2 - 70, 10, 140)
hindere = []
for i in range(3):
    hinder = Hinder(BREDDE/2 -5, random.randint(0, HOYDE-80), 10, 80)
    hindere.append(hinder)

vindu = pygame.display.set_mode((BREDDE, HOYDE))
klokke = pygame.time.Clock()

game_font = pygame.font.Font("freesansbold.ttf", 32)

bakgrunnsfarge = pygame.Color('grey12')
light_grey = (200, 200, 200)

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            raise SystemExit
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                spiller.speed += 7
            if event.key == pygame.K_UP:
                spiller.speed -= 7
            if event.key == pygame.K_s:
                spiller2.speed += 7
            if event.key == pygame.K_w:
                spiller2.speed -= 7
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_DOWN:
                spiller.speed -= 7
            if event.key == pygame.K_s:
                spiller2.speed -= 7
            if event.key == pygame.K_UP:
                spiller.speed += 7
            if event.key == pygame.K_w:
                spiller2.speed += 7
        
    for ball in baller:
        ball.animation()
    spiller.animation()
    spiller2.animation()
    for ball in baller:
        if ball.ramme.x <= 0:
            spiller.score += 1
            if len(baller) > 1:
                baller.remove(ball)
            else:
                ball.restart()

        if ball.ramme.x >= BREDDE:
            spiller2.score += 1
            if len(baller) > 1:
                baller.remove(ball)
            else:
                ball.restart()

    for ball in baller:
        if spiller.ramme.colliderect(ball.ramme):
            ball.speed_x *= -1
            if len(baller) < 5:
                center_x = spiller.ramme.centerx
                center_y = spiller.ramme.centery
                baller.append(Ball(center_x, center_y, 30, 30))

        if spiller2.ramme.colliderect(ball.ramme):
            ball.speed_x *= -1
            if len(baller) < 5:
                center_x = spiller2.ramme.centerx
                center_y = spiller2.ramme.centerx
                baller.append(Ball(center_x, center_y, 30, 30))

            

            

    for hinder in hindere:
        for ball in baller:
            if ball.ramme.colliderect(hinder.ramme):
                ball.speed_x *= -1

    
    vindu.fill(bakgrunnsfarge)       

    spiller.tegn(vindu, light_grey, spiller.ramme)
    spiller2.tegn(vindu, light_grey, spiller2.ramme)

    for hinder in hindere:
        hinder.tegn(vindu, light_grey, hinder.ramme)
    for ball in baller:
        ball.tegn_ball(vindu, light_grey, ball.ramme)
    pygame.draw.aaline(vindu, light_grey, (BREDDE/2,0), (BREDDE/2, HOYDE))
        
    spiller_text = game_font.render(f"{spiller.score}", False, light_grey)
    vindu.blit(spiller_text, (660, 400))
    
    motstander_text = game_font.render(f"{spiller2.score}", False, light_grey)
    vindu.blit(motstander_text, (600, 400))

    
    pygame.display.flip()
    klokke.tick(FPS)
